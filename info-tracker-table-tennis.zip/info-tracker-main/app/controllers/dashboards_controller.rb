# frozen_string_literal: true

class DashboardsController < ApplicationController
  def show; end
end
