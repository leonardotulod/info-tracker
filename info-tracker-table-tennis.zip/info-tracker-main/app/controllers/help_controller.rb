# frozen_string_literal: true

class HelpController < ApplicationController
  def index; end
end
