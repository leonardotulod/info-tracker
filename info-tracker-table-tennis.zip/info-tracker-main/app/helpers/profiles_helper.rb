# frozen_string_literal: true

module ProfilesHelper
end
